# VectorShift Frontend Technical Assessment — Solution

A pipeline builder (drag nodes onto a canvas, wire them together, submit for
validation) built with React + React Flow on the frontend and FastAPI on the
backend.

## Quick start

**Backend**
```bash
cd backend
python3 -m venv venv && source venv/bin/activate   # optional but recommended
pip install -r requirements.txt
uvicorn main:app --reload
```
Runs at `http://localhost:8000`.

**Frontend** (separate terminal)
```bash
cd frontend
npm install
npm start
```
Runs at `http://localhost:3000` and talks to the backend URL set in
`frontend/.env` (`REACT_APP_API_URL`, defaults to `http://localhost:8000`).

## What's implemented

### Part 1 — Node abstraction (`frontend/src/nodes/BaseNode.js`)
Every node is a thin config object handed to `<BaseNode />`, which owns all
shared behavior: card layout/styling, Handle rendering and positioning, form
field rendering (text / number / select / textarea), and wiring field edits
back into the zustand store via `updateNodeField`. A new node is typically
10–20 lines. The four original nodes (Input, Output, LLM, Text) were
refactored onto this abstraction, and five new nodes were added to
demonstrate it:

- **Math** — two inputs (`a`, `b`), an operation select, one output
- **Filter** — one input, a condition field, two labeled outputs (`match` / `reject`)
- **Delay** — a numeric duration field
- **API Request** — a method select + URL field
- **Conditional** — an expression field, two labeled outputs (`true` / `false`)

### Part 2 — Styling
A small design-token system (`frontend/src/index.css`) drives a consistent
look across the app: a dark gradient header with a live node/edge counter, a
sidebar tool palette, and node cards that are visually shared but
color-coded per type (see `accent-*` classes in `BaseNode.css`).

### Part 3 — Text node logic (`frontend/src/nodes/textNode.js`)
- The textarea auto-grows in width (based on the longest line) and height
  (measured against a hidden mirror element), so the node always fits its
  content.
- Any `{{ variableName }}` pattern (valid JS identifier) in the text is
  parsed on every keystroke and turned into a target `Handle` on the left
  edge of the node, named after the variable, so it can be connected to
  another node's output. Handles are recomputed/deduplicated automatically
  as the text changes.

### Part 4 — Backend integration
- `frontend/src/submit.js` sends the current `nodes`/`edges` as JSON to
  `POST /pipelines/parse` and shows an alert with the response.
- `backend/main.py` accepts that payload, counts nodes/edges, and determines
  whether the graph is a DAG using Kahn's algorithm (repeatedly removing
  zero-indegree nodes; it's a DAG iff every node gets removed), returning
  `{ num_nodes, num_edges, is_dag }`.

## Notes
- `frontend/.env` sets `DISABLE_ESLINT_PLUGIN=true`. This works around a
  known version conflict between `react-scripts@5`'s bundled ESLint
  integration and the `eslint-plugin-jest` version npm currently resolves
  (`Environment key "jest/globals" is unknown`) — unrelated to this
  project's code. Your editor's own ESLint/linting is unaffected.
- CORS is open (`allow_origins=["*"]`) for local development; restrict this
  before deploying the backend publicly.
