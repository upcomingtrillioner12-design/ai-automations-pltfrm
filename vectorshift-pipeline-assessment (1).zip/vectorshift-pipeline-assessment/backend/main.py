# main.py
# --------------------------------------------------
# Minimal FastAPI backend for the Pipeline Studio frontend.
#
# POST /pipelines/parse accepts the current nodes/edges of a React Flow
# pipeline and returns:
#   { num_nodes: int, num_edges: int, is_dag: bool }
# --------------------------------------------------

from collections import defaultdict, deque
from typing import List, Optional

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Pipeline Studio Backend")

# Allow the React dev server (and any other origin) to call this API directly
# from the browser.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class PipelineNode(BaseModel):
    id: str
    type: Optional[str] = None
    data: Optional[dict] = None


class PipelineEdge(BaseModel):
    id: Optional[str] = None
    source: str
    target: str


class Pipeline(BaseModel):
    nodes: List[PipelineNode] = []
    edges: List[PipelineEdge] = []


def is_directed_acyclic_graph(nodes: List[PipelineNode], edges: List[PipelineEdge]) -> bool:
    """Kahn's algorithm: a graph is a DAG iff all nodes can be topologically
    ordered, i.e. repeatedly removing zero-indegree nodes consumes every
    node in the graph."""

    node_ids = {node.id for node in nodes}
    adjacency = defaultdict(list)
    indegree = {node_id: 0 for node_id in node_ids}

    for edge in edges:
        # Ignore any dangling edges that don't correspond to a known node.
        if edge.source in node_ids and edge.target in node_ids:
            adjacency[edge.source].append(edge.target)
            indegree[edge.target] += 1

    queue = deque([node_id for node_id in node_ids if indegree[node_id] == 0])
    visited_count = 0

    while queue:
        current = queue.popleft()
        visited_count += 1
        for neighbor in adjacency[current]:
            indegree[neighbor] -= 1
            if indegree[neighbor] == 0:
                queue.append(neighbor)

    # If every node could be "removed", there was no cycle.
    return visited_count == len(node_ids)


@app.get('/')
def read_root():
    return {'Ping': 'Pong'}


@app.post('/pipelines/parse')
def parse_pipeline(pipeline: Pipeline):
    num_nodes = len(pipeline.nodes)
    num_edges = len(pipeline.edges)
    dag = is_directed_acyclic_graph(pipeline.nodes, pipeline.edges)

    return {
        'num_nodes': num_nodes,
        'num_edges': num_edges,
        'is_dag': dag,
    }
