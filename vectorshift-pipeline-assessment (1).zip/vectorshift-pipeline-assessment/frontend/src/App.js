import { PipelineToolbar } from './toolbar';
import { PipelineUI } from './ui';
import { SubmitButton } from './submit';
import { useStore } from './store';
import { shallow } from 'zustand/shallow';

const countSelector = (state) => ({
  nodeCount: state.nodes.length,
  edgeCount: state.edges.length,
});

function Header() {
  const { nodeCount, edgeCount } = useStore(countSelector, shallow);
  return (
    <header className="app-header">
      <div className="app-header-brand">
        <span className="app-header-mark">VS</span>
        <div>
          <h1 className="app-header-title">Pipeline Studio</h1>
          <p className="app-header-subtitle">Build, wire up, and validate your pipeline</p>
        </div>
      </div>
      <div className="app-header-stats">
        <span className="stat-pill">{nodeCount} node{nodeCount === 1 ? '' : 's'}</span>
        <span className="stat-pill">{edgeCount} edge{edgeCount === 1 ? '' : 's'}</span>
      </div>
    </header>
  );
}

function App() {
  return (
    <div className="app">
      <Header />
      <div className="app-body">
        <PipelineToolbar />
        <PipelineUI />
      </div>
      <SubmitButton />
    </div>
  );
}

export default App;
