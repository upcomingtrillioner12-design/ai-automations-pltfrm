// BaseNode.js
// --------------------------------------------------
// Shared abstraction for every node in the pipeline editor.
//
// Every concrete node (Input, Output, LLM, Text, Math, ...) is just a thin
// config wrapper around <BaseNode />: it declares a title/icon, the Handles
// it needs, and the form Fields it needs. BaseNode takes care of layout,
// styling, handle positioning, field rendering and wiring field changes back
// into the zustand store. This means new nodes can be added in ~15 lines
// instead of duplicating markup, state, and styling every time.
// --------------------------------------------------

import { Handle } from 'reactflow';
import { useStore } from '../store';
import { shallow } from 'zustand/shallow';
import './BaseNode.css';

const updateNodeFieldSelector = (state) => state.updateNodeField;

/**
 * @param {string} id - node id (provided by React Flow)
 * @param {object} data - node data (provided by React Flow)
 * @param {string} title - text shown in the node header
 * @param {string} [icon] - small emoji/icon shown next to the title
 * @param {string} [accent] - css class suffix used to color-code the node type
 * @param {Array}  [handles] - [{ type: 'source'|'target', position, id, label, style }]
 * @param {Array}  [fields] - [{ name, label, type: 'text'|'select'|'number'|'textarea', defaultValue, options, rows, placeholder }]
 * @param {number|string} [minWidth]
 * @param {React.ReactNode} [children] - extra custom body content (used by nodes with bespoke logic, e.g. TextNode)
 * @param {React.ReactNode} [footer] - optional footer row (e.g. helper text)
 */
export const BaseNode = ({
  id,
  data = {},
  title,
  icon,
  accent = 'default',
  handles = [],
  fields = [],
  minWidth = 220,
  children,
  footer,
}) => {
  const updateNodeField = useStore(updateNodeFieldSelector, shallow);

  const handleFieldChange = (name, value) => {
    updateNodeField(id, name, value);
  };

  return (
    <div className={`base-node accent-${accent}`} style={{ minWidth }}>
      {handles.map((handle) => (
        <div key={handle.id} className="handle-wrap" style={handle.style}>
          <Handle
            type={handle.type}
            position={handle.position}
            id={handle.id}
            className={`base-handle base-handle-${handle.type}`}
          />
          {handle.label && (
            <span className={`handle-label handle-label-${handle.type}`}>{handle.label}</span>
          )}
        </div>
      ))}

      <div className="base-node-header">
        {icon && <span className="base-node-icon">{icon}</span>}
        <span className="base-node-title">{title}</span>
      </div>

      {(fields.length > 0 || children) && (
        <div className="base-node-body">
          {fields.map((field) => {
            const value = data[field.name] ?? field.defaultValue ?? '';
            return (
              <label className="base-node-field" key={field.name}>
                {field.label && <span className="base-node-label">{field.label}</span>}
                {field.type === 'select' ? (
                  <select
                    className="base-node-select nodrag"
                    value={value}
                    onChange={(e) => handleFieldChange(field.name, e.target.value)}
                  >
                    {field.options.map((opt) => (
                      <option key={opt.value} value={opt.value}>
                        {opt.label}
                      </option>
                    ))}
                  </select>
                ) : field.type === 'textarea' ? (
                  <textarea
                    className="base-node-textarea nodrag"
                    rows={field.rows || 2}
                    placeholder={field.placeholder}
                    value={value}
                    onChange={(e) => handleFieldChange(field.name, e.target.value)}
                  />
                ) : (
                  <input
                    type={field.type || 'text'}
                    className="base-node-input nodrag"
                    placeholder={field.placeholder}
                    value={value}
                    onChange={(e) => handleFieldChange(field.name, e.target.value)}
                  />
                )}
              </label>
            );
          })}
          {children}
        </div>
      )}

      {footer && <div className="base-node-footer">{footer}</div>}
    </div>
  );
};
