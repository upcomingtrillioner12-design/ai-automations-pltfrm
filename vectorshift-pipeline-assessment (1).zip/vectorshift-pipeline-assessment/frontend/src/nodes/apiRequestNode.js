// apiRequestNode.js
// Demonstrates a node combining a select field and a text field.

import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';

export const APIRequestNode = ({ id, data }) => {
  return (
    <BaseNode
      id={id}
      data={data}
      title="API Request"
      icon="🌐"
      accent="api"
      handles={[
        { type: 'target', position: Position.Left, id: `${id}-trigger` },
        { type: 'source', position: Position.Right, id: `${id}-response` },
      ]}
      fields={[
        {
          name: 'method',
          label: 'Method',
          type: 'select',
          defaultValue: 'GET',
          options: [
            { value: 'GET', label: 'GET' },
            { value: 'POST', label: 'POST' },
            { value: 'PUT', label: 'PUT' },
            { value: 'DELETE', label: 'DELETE' },
          ],
        },
        {
          name: 'url',
          label: 'URL',
          type: 'text',
          placeholder: 'https://api.example.com/resource',
          defaultValue: '',
        },
      ]}
    />
  );
};
