// conditionalNode.js
// Demonstrates a node with one input and two conditionally-labeled outputs.

import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';

export const ConditionalNode = ({ id, data }) => {
  return (
    <BaseNode
      id={id}
      data={data}
      title="Conditional"
      icon="🔀"
      accent="conditional"
      handles={[
        { type: 'target', position: Position.Left, id: `${id}-input` },
        { type: 'source', position: Position.Right, id: `${id}-true`, label: 'true', style: { top: '33%' } },
        { type: 'source', position: Position.Right, id: `${id}-false`, label: 'false', style: { top: '66%' } },
      ]}
      fields={[
        {
          name: 'expression',
          label: 'If',
          type: 'text',
          placeholder: 'e.g. input === "ready"',
          defaultValue: '',
        },
      ]}
    />
  );
};
