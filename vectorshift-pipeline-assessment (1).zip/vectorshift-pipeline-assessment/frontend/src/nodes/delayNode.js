// delayNode.js
// Demonstrates a node with a numeric field.

import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';

export const DelayNode = ({ id, data }) => {
  return (
    <BaseNode
      id={id}
      data={data}
      title="Delay"
      icon="⏱️"
      accent="delay"
      handles={[
        { type: 'target', position: Position.Left, id: `${id}-in` },
        { type: 'source', position: Position.Right, id: `${id}-out` },
      ]}
      fields={[
        {
          name: 'durationMs',
          label: 'Duration (ms)',
          type: 'number',
          defaultValue: 1000,
        },
      ]}
    />
  );
};
