// filterNode.js
// Demonstrates a node with a text field and two differently-labeled
// outputs (matched / rejected).

import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';

export const FilterNode = ({ id, data }) => {
  return (
    <BaseNode
      id={id}
      data={data}
      title="Filter"
      icon="🔍"
      accent="filter"
      handles={[
        { type: 'target', position: Position.Left, id: `${id}-items` },
        { type: 'source', position: Position.Right, id: `${id}-matched`, label: 'match', style: { top: '33%' } },
        { type: 'source', position: Position.Right, id: `${id}-rejected`, label: 'reject', style: { top: '66%' } },
      ]}
      fields={[
        {
          name: 'condition',
          label: 'Condition',
          type: 'text',
          placeholder: 'e.g. value > 10',
          defaultValue: '',
        },
      ]}
    />
  );
};
