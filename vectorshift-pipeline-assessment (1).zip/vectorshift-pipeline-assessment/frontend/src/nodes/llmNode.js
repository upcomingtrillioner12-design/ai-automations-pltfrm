// llmNode.js

import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';

export const LLMNode = ({ id, data }) => {
  return (
    <BaseNode
      id={id}
      data={data}
      title="LLM"
      icon="🤖"
      accent="llm"
      handles={[
        { type: 'target', position: Position.Left, id: `${id}-system`, label: 'system', style: { top: '33%' } },
        { type: 'target', position: Position.Left, id: `${id}-prompt`, label: 'prompt', style: { top: '66%' } },
        { type: 'source', position: Position.Right, id: `${id}-response` },
      ]}
      fields={[
        {
          name: 'model',
          label: 'Model',
          type: 'select',
          defaultValue: 'gpt-4o',
          options: [
            { value: 'gpt-4o', label: 'GPT-4o' },
            { value: 'claude-sonnet-5', label: 'Claude Sonnet 5' },
            { value: 'claude-opus-4-8', label: 'Claude Opus 4.8' },
          ],
        },
      ]}
      footer="Takes a system prompt + a prompt, returns a response."
    />
  );
};
