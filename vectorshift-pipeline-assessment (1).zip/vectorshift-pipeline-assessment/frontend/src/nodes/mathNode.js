// mathNode.js
// Demonstrates the abstraction: two target handles + a select field,
// built in a few lines thanks to BaseNode.

import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';

export const MathNode = ({ id, data }) => {
  return (
    <BaseNode
      id={id}
      data={data}
      title="Math"
      icon="➗"
      accent="math"
      handles={[
        { type: 'target', position: Position.Left, id: `${id}-a`, label: 'a', style: { top: '33%' } },
        { type: 'target', position: Position.Left, id: `${id}-b`, label: 'b', style: { top: '66%' } },
        { type: 'source', position: Position.Right, id: `${id}-result` },
      ]}
      fields={[
        {
          name: 'operation',
          label: 'Operation',
          type: 'select',
          defaultValue: 'add',
          options: [
            { value: 'add', label: 'a + b' },
            { value: 'subtract', label: 'a - b' },
            { value: 'multiply', label: 'a × b' },
            { value: 'divide', label: 'a ÷ b' },
          ],
        },
      ]}
    />
  );
};
