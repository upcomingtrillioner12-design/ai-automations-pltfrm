// textNode.js
// --------------------------------------------------
// Text node with two extra behaviors on top of the base abstraction:
//   1. The node grows (width + height) to fit whatever the user types.
//   2. Any {{ variableName }} written in the text creates a target Handle
//      on the left edge of the node, named after the variable, so it can
//      be wired up to another node's output.
// --------------------------------------------------

import { useState, useMemo, useRef, useLayoutEffect } from 'react';
import { Position } from 'reactflow';
import { BaseNode } from './BaseNode';
import { useStore } from '../store';
import { shallow } from 'zustand/shallow';
import './textNode.css';

// Matches {{ variableName }} where variableName is a valid JS identifier.
const VARIABLE_PATTERN = /\{\{\s*([A-Za-z_$][A-Za-z0-9_$]*)\s*\}\}/g;

const MIN_WIDTH = 240;
const MAX_WIDTH = 460;
const MIN_HEIGHT = 32;

const extractVariables = (text) => {
  const found = [];
  const seen = new Set();
  let match;
  VARIABLE_PATTERN.lastIndex = 0;
  while ((match = VARIABLE_PATTERN.exec(text)) !== null) {
    if (!seen.has(match[1])) {
      seen.add(match[1]);
      found.push(match[1]);
    }
  }
  return found;
};

const updateNodeFieldSelector = (state) => state.updateNodeField;

export const TextNode = ({ id, data }) => {
  const updateNodeField = useStore(updateNodeFieldSelector, shallow);
  const [text, setText] = useState(data?.text ?? '{{input}}');
  const [textareaHeight, setTextareaHeight] = useState(MIN_HEIGHT);
  const textareaRef = useRef(null);
  const measureRef = useRef(null);

  const variables = useMemo(() => extractVariables(text), [text]);

  // Width grows with the longest line, clamped to a sensible range.
  const width = useMemo(() => {
    const longestLine = text.split('\n').reduce((max, line) => Math.max(max, line.length), 0);
    const estimated = MIN_WIDTH + Math.max(0, longestLine - 24) * 6.5;
    return Math.round(Math.min(MAX_WIDTH, Math.max(MIN_WIDTH, estimated)));
  }, [text]);

  // Height grows with actual rendered content (wrapped lines included).
  useLayoutEffect(() => {
    if (measureRef.current) {
      measureRef.current.style.width = `${width - 24}px`;
      const scrollHeight = measureRef.current.scrollHeight;
      setTextareaHeight(Math.max(MIN_HEIGHT, scrollHeight));
    }
  }, [text, width]);

  const handleTextChange = (e) => {
    const value = e.target.value;
    setText(value);
    updateNodeField(id, 'text', value);
  };

  const handles = useMemo(() => {
    const variableHandles = variables.map((name, index) => ({
      type: 'target',
      position: Position.Left,
      id: `${id}-${name}`,
      label: name,
      style: { top: `${((index + 1) / (variables.length + 1)) * 100}%` },
    }));
    return [...variableHandles, { type: 'source', position: Position.Right, id: `${id}-output` }];
  }, [variables, id]);

  return (
    <BaseNode id={id} data={data} title="Text" icon="🧩" accent="text" handles={handles} minWidth={width}>
      <label className="base-node-field">
        <span className="base-node-label">Text</span>
        <textarea
          ref={textareaRef}
          className="base-node-textarea nodrag"
          style={{ height: textareaHeight, width: '100%' }}
          value={text}
          onChange={handleTextChange}
          placeholder="Type text, use {{ variable }} to add an input"
        />
      </label>
      {/* Hidden element used purely to measure how tall the text needs to render at. */}
      <div
        ref={measureRef}
        aria-hidden="true"
        className="base-node-textarea text-measure"
      >
        {`${text}\u200b`}
      </div>
      {variables.length > 0 && (
        <div className="text-node-vars">
          {variables.map((v) => (
            <span className="text-node-var-chip" key={v}>{`{{${v}}}`}</span>
          ))}
        </div>
      )}
    </BaseNode>
  );
};
