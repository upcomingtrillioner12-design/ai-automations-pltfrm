// submit.js

import { useState } from 'react';
import { useStore } from './store';
import { shallow } from 'zustand/shallow';

const selector = (state) => ({ nodes: state.nodes, edges: state.edges });

// Configurable via frontend/.env → REACT_APP_API_URL. Defaults to the local
// FastAPI dev server started with `uvicorn main:app --reload`.
const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000';

export const SubmitButton = () => {
  const { nodes, edges } = useStore(selector, shallow);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async () => {
    setLoading(true);
    try {
      const response = await fetch(`${API_URL}/pipelines/parse`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          nodes: nodes.map((node) => ({ id: node.id, type: node.type, data: node.data })),
          edges: edges.map((edge) => ({ id: edge.id, source: edge.source, target: edge.target })),
        }),
      });

      if (!response.ok) {
        throw new Error(`Server responded with status ${response.status}`);
      }

      const result = await response.json();

      alert(
        'Pipeline analysis\n\n' +
        `Nodes: ${result.num_nodes}\n` +
        `Edges: ${result.num_edges}\n` +
        `Is DAG: ${result.is_dag ? 'Yes' : 'No'}`
      );
    } catch (error) {
      alert(
        'Could not reach the backend.\n\n' +
        `Make sure the FastAPI server is running at ${API_URL}\n` +
        `(cd backend && uvicorn main:app --reload)\n\n` +
        `Details: ${error.message}`
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="submit-bar">
      <span className="submit-hint">Wire up your nodes, then submit to analyze the pipeline.</span>
      <button className="submit-button" onClick={handleSubmit} disabled={loading}>
        {loading ? 'Submitting…' : 'Submit Pipeline'}
      </button>
    </div>
  );
}
