// toolbar.js

import { DraggableNode } from './draggableNode';

const NODE_LIBRARY = [
  { type: 'customInput', label: 'Input', icon: '📥', accent: 'input' },
  { type: 'llm', label: 'LLM', icon: '🤖', accent: 'llm' },
  { type: 'customOutput', label: 'Output', icon: '📤', accent: 'output' },
  { type: 'text', label: 'Text', icon: '🧩', accent: 'text' },
  { type: 'math', label: 'Math', icon: '➗', accent: 'math' },
  { type: 'filter', label: 'Filter', icon: '🔍', accent: 'filter' },
  { type: 'delay', label: 'Delay', icon: '⏱️', accent: 'delay' },
  { type: 'apiRequest', label: 'API Request', icon: '🌐', accent: 'api' },
  { type: 'conditional', label: 'Conditional', icon: '🔀', accent: 'conditional' },
];

export const PipelineToolbar = () => {

    return (
        <aside className="toolbar">
            <div className="toolbar-heading">Nodes</div>
            <p className="toolbar-hint">Drag a node onto the canvas</p>
            <div className="toolbar-list">
                {NODE_LIBRARY.map((node) => (
                  <DraggableNode key={node.type} {...node} />
                ))}
            </div>
        </aside>
    );
};
